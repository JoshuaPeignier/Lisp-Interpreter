
(*************** Global variables ************)

let debug = ref(true);;

let global_env_ref = ref ([]:environment);;

let current_channel = ref stdin;;

let max_print_level = ref(4);;

let max_print_env_level = ref(2);;

let print_env_hidden = ref(false);;

